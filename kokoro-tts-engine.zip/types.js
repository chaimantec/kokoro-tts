const o="Sherlock TTS";export{o as V};
